request = {
    "method": "GET",
    "uri": uri("/\xc3\xa0%20k"),
    "version": (1, 0),
    "headers": [
    ],
    "body": ''
}
