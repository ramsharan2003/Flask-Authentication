Generate Documentation
======================

Requirements
------------

To generate documentation you need to install:

 - Python >= 3.7
 - Sphinx (https://www.sphinx-doc.org/)


Generate html
-------------
::

    $ make html

The command generates html document inside ``build/html`` dir.
